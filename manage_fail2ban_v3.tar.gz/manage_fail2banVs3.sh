#!/usr/bin/env bash
# manage_fail2banVs2.sh
# Unified Fail2Ban manager: preserves Vs2 features + full HTML Gmail mailer (whois, rdns, log snippet)
set -euo pipefail

# ------------------------------- Helpers --------------------------------
log()  { printf '%s\n' "$*"; }
ok()   { printf '✔ %s\n' "$*"; }
warn() { printf '⚠  %s\n' "$*" >&2; }
err()  { printf '✖ %s\n' "$*" >&2; exit 1; }

need_root() {
  if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    echo "Re-running with sudo..."
    exec sudo -E bash "$0" "$@"
  fi
}

detect_pm() {
  if command -v apt-get >/dev/null 2>&1; then PM="apt"
  elif command -v dnf      >/dev/null 2>&1; then PM="dnf"
  elif command -v yum      >/dev/null 2>&1; then PM="yum"
  elif command -v pacman   >/dev/null 2>&1; then PM="pacman"
  else PM=""
  fi
}

service_restart() {
  if command -v systemctl >/dev/null 2>&1; then
    systemctl daemon-reload || true
    systemctl enable fail2ban || true
    systemctl restart fail2ban || systemctl start fail2ban || true
  else
    service fail2ban restart || service fail2ban start || true
  fi
}

service_stop() {
  if command -v systemctl >/dev/null 2>&1; then
    systemctl stop fail2ban || true
  else
    service fail2ban stop || true
  fi
}

# Detect default logpath for ssh auth
detect_logpath() {
  if [[ -f /var/log/secure ]]; then
    SSH_LOGPATH="/var/log/secure"
  else
    SSH_LOGPATH="/var/log/auth.log"
  fi
}

# Detect effective sshd port (works if sshd present)
get_effective_ssh_port() {
  local p
  if command -v sshd >/dev/null 2>&1; then
    p="$(sshd -T 2>/dev/null | awk '/^port /{print $2; exit}')" || true
  fi
  [[ -z "${p:-}" ]] && p=22
  p="$(echo -n "$p" | tr -cd '0-9')" || true
  [[ -z "${p:-}" ]] && p=22
  SSH_PORT="$p"
}

prompt_for_ssh_port() {
  get_effective_ssh_port
  local in
  read -rp "SSH port to protect [default: ${SSH_PORT}]: " in || true
  in="$(echo -n "${in:-}" | tr -cd '0-9')"
  if [[ -n "$in" ]]; then
    if (( in>=1 && in<=65535 )); then
      SSH_PORT="$in"
    else
      warn "Invalid port '$in'. Using ${SSH_PORT}."
    fi
  fi
  ok "Using SSH port: ${SSH_PORT}"
}

# ------------------------ Firewall / backend helpers ---------------------
detect_firewall_backend() {
  if command -v nft >/dev/null 2>&1; then
    FW_BACKEND="nft"; BANACTION="nftables-multiport"
  else
    FW_BACKEND="iptables"; BANACTION="iptables-multiport"
  fi
  # prefer legacy iptables if explicitly present as legacy
  if command -v iptables >/dev/null 2>&1 && iptables -V 2>/dev/null | grep -qi 'legacy'; then
    FW_BACKEND="iptables"; BANACTION="iptables-multiport"
  fi
}

ensure_jump_iptables() {
  local port="$1"
  iptables -nL f2b-sshd >/dev/null 2>&1 || { iptables -N f2b-sshd; iptables -A f2b-sshd -j RETURN; }
  iptables -C INPUT -p tcp --dport "$port" -j f2b-sshd 2>/dev/null || iptables -I INPUT 1 -p tcp --dport "$port" -j f2b-sshd
  ip6tables -nL f2b-sshd >/dev/null 2>&1 || { ip6tables -N f2b-sshd; ip6tables -A f2b-sshd -j RETURN; }
  ip6tables -C INPUT -p tcp --dport "$port" -j f2b-sshd 2>/dev/null || ip6tables -I INPUT 1 -p tcp --dport "$port" -j f2b-sshd
}

flush_chain_iptables() {
  local port="$1"
  iptables  -D INPUT -p tcp --dport "$port" -j f2b-sshd 2>/dev/null || true
  iptables  -F f2b-sshd 2>/dev/null || true
  iptables  -X f2b-sshd 2>/dev/null || true
  iptables  -N f2b-sshd || true
  iptables  -A f2b-sshd -j RETURN || true
  iptables  -I INPUT 1 -p tcp --dport "$port" -j f2b-sshd || true

  ip6tables -D INPUT -p tcp --dport "$port" -j f2b-sshd 2>/dev/null || true
  ip6tables -F f2b-sshd 2>/dev/null || true
  ip6tables -X f2b-sshd 2>/dev/null || true
  ip6tables -N f2b-sshd || true
  ip6tables -A f2b-sshd -j RETURN || true
  ip6tables -I INPUT 1 -p tcp --dport "$port" -j f2b-sshd || true
}

list_jails() {
  command -v fail2ban-client >/dev/null 2>&1 || { echo ""; return; }
  fail2ban-client status 2>/dev/null | awk -F': ' '/Jail list:/ {gsub(/, /," "); print $2}'
}

# ----------------------------- Unban features ----------------------------
unban_single_ip() {
  need_root
  read -rp "IP to unban: " ip
  [[ -z "$ip" ]] && err "No IP provided."
  local j; j="$(list_jails)"
  [[ -z "$j" ]] && { warn "No jails detected; restarting fail2ban..."; service_restart; j="$(list_jails)"; }
  [[ -z "$j" ]] && err "Still no jails."
  local okany=false
  for x in $j; do
    if fail2ban-client set "$x" unbanip "$ip" >/dev/null 2>&1; then ok "Unbanned $ip from '$x'"; okany=true; fi
  done
  [[ "$okany" == "false" ]] && warn "IP $ip was not banned."
}

unban_all_ips() {
  need_root

  # 1) Try global unban (Fail2Ban >= 0.11)
  if fail2ban-client unban --all >/dev/null 2>&1; then
    ok "All bans removed via global 'fail2ban-client unban --all'."
    return 0
  fi

  # 2) Enumerate jails
  local jails; jails="$(list_jails)"
  [[ -z "$jails" ]] && { warn "No jails detected; restarting fail2ban..."; service_restart; jails="$(list_jails)"; }
  [[ -z "$jails" ]] && err "Still no jails after restart."

  local total_cleared=0
  for J in $jails; do
    # per-jail unban if supported
    if fail2ban-client unban --all "$J" >/dev/null 2>&1; then
      ok "Cleared all bans in jail '$J' via 'unban --all'."
      continue
    fi

    # Fallback: enumerate banned IPs
    mapfile -t ips < <(
      fail2ban-client get "$J" banned 2>/dev/null \
        | tr -d '\r' \
        | sed "s/[',]//g" \
        | sed '/^$/d'
    )

    if ((${#ips[@]})); then
      local cleared=0
      for ip in "${ips[@]}"; do
        if [[ "$ip" =~ ^[0-9A-Fa-f:.]+$ ]]; then
          if fail2ban-client set "$J" unbanip "$ip" >/dev/null 2>&1; then
            ((cleared++))
            ((total_cleared++))
          fi
        else
          warn "Skipped invalid entry in '$J': $ip"
        fi
      done
      ok "Cleared ${cleared} ban(s) in jail '$J' (enumeration mode)."
    else
      ok "No bans found in jail '$J'."
    fi
  done

  ok "UNBAN ALL complete. Total bans cleared: ${total_cleared}"
  return 0
}

purge_db_and_flush() {
  need_root
  get_effective_ssh_port
  detect_firewall_backend
  service_stop
  rm -f /var/lib/fail2ban/fail2ban.sqlite3 || true
  if [[ "${FW_BACKEND}" == "iptables" ]]; then
    flush_chain_iptables "${SSH_PORT}"
  fi
  service_restart
  ok "Fail2Ban DB purged, chain rebuilt, service restarted (port ${SSH_PORT}, backend ${FW_BACKEND})."
}

# --------------------------- Install / Configure -------------------------
install_fail2ban_stack() {
  need_root
  detect_pm || true
  detect_firewall_backend
  prompt_for_ssh_port
  detect_logpath

  # Packages (best effort)
  if [[ -n "${PM:-}" ]]; then
    if ! command -v fail2ban-client >/dev/null 2>&1; then
      case "$PM" in
        apt)    apt-get update -y || true; apt-get install -y fail2ban || true ;;
        dnf)    dnf install -y fail2ban || true ;;
        yum)    yum install -y epel-release || true; yum install -y fail2ban || true ;;
        pacman) pacman -Sy --noconfirm fail2ban || true ;;
      esac
    fi
    command -v whois >/dev/null 2>&1 || {
      case "$PM" in
        apt)    apt-get install -y whois || true ;;
        dnf)    dnf install -y whois || true ;;
        yum)    yum install -y whois || true ;;
        pacman) pacman -Sy --noconfirm whois || true ;;
      esac
    }
  fi

  # Align iptables/nft (best effort)
  if [[ "${FW_BACKEND}" == "iptables" ]] && command -v update-alternatives >/dev/null 2>&1; then
    update-alternatives --set iptables  /usr/sbin/iptables-legacy  || true
    update-alternatives --set ip6tables /usr/sbin/ip6tables-legacy || true
  elif [[ "${FW_BACKEND}" == "nft" ]] && command -v update-alternatives >/dev/null 2>&1; then
    update-alternatives --set iptables  /usr/sbin/iptables-nft  || true
    update-alternatives --set ip6tables /usr/sbin/ip6tables-nft || true
  fi

  # --- Email prompts (optional; Enter = skip) ---
  echo "== Email notifications (OPTIONAL). Press Enter to skip each field =="
  read -rp "Gmail sender (From): " GMAIL_SENDER || true
  read -rp "Recipient (To)     : " GMAIL_DEST   || true
  APP_PWD=""
  if [[ -n "${GMAIL_SENDER:-}" && -n "${GMAIL_DEST:-}" ]]; then
    while true; do
      read -rsp "Gmail App Password (16 chars, no spaces): " APP_PWD || true; echo
      [[ -z "${APP_PWD:-}" ]] && { echo "Skipped email setup."; break; }
      if [[ ${#APP_PWD} -eq 16 && ! "$APP_PWD" =~ [[:space:]] ]]; then
        break
      else
        echo "Invalid app password. Try again or press Enter to skip."
      fi
    done
  fi

  # Stop & backup (best effort)
  service_stop
  TS="$(date +%Y%m%d_%H%M%S)"; BACKUP_DIR="/etc/fail2ban/backup_$TS"
  mkdir -p "$BACKUP_DIR"; tar -C /etc -cf "$BACKUP_DIR/fail2ban-backup.tar" fail2ban 2>/dev/null || true
  mkdir -p /etc/fail2ban/filter.d /etc/fail2ban/action.d /etc/fail2ban/jail.d /usr/local/bin /etc/systemd/system/fail2ban.service.d

  # --- jail.local: FORCE firewall action, add monitor jail and optionally mailer ---
  {
    echo "[DEFAULT]"
    echo "backend  = systemd"
    echo "usedns   = no"
    echo "bantime  = -1"
    echo "findtime = 10m"
    echo "maxretry = 3"
    echo "banaction = ${BANACTION}"
    if [[ -n "${GMAIL_SENDER:-}" && -n "${GMAIL_DEST:-}" && -n "${APP_PWD:-}" ]]; then
      # include both firewall ban action and mailer
      echo 'action = %(banaction)s[name=%(__name__)s, port="%(port)s", protocol="%(protocol)s"]'
      echo "         sendmail-gmail[name=SSH, dest=${GMAIL_DEST}, sender=${GMAIL_SENDER}]"
    else
      echo 'action = %(banaction)s[name=%(__name__)s, port="%(port)s", protocol="%(protocol)s"]'
    fi

    echo
    echo "[sshd]"
    echo "enabled   = true"
    echo "port      = ${SSH_PORT}"
    echo "filter    = sshd"
    echo "journalmatch = _SYSTEMD_UNIT=sshd.service + _COMM=sshd"
    echo
    # monitor jail: emails on EVERY attempt (including Accepted), no firewall action
    echo "[sshd-monitor]"
    echo "enabled   = true"
    echo "port      = ${SSH_PORT}"
    echo "filter    = sshd-monitor"
    echo "maxretry  = 1"
    echo "findtime  = 60"
    echo "bantime   = 10s"
    echo "banaction = dummy"
    if [[ -n "${GMAIL_SENDER:-}" && -n "${GMAIL_DEST:-}" && -n "${APP_PWD:-}" ]]; then
      echo "action    = sendmail-gmail[name=SSH-ATTEMPT, dest=${GMAIL_DEST}, sender=${GMAIL_SENDER}]"
    fi
  } > /etc/fail2ban/jail.local
  chmod 0644 /etc/fail2ban/jail.local
  ok "Wrote /etc/fail2ban/jail.local"

  # --- Filters: use standard sshd and a monitor filter including Accepted lines ---
  cat > /etc/fail2ban/filter.d/sshd-monitor.conf <<'FILTER_MON'
[INCLUDES]
before = common.conf

[Definition]
failregex = ^%(__prefix_line)sFailed password for(?: invalid user)? .* from <HOST>.*$
            ^%(__prefix_line)sInvalid user .* from <HOST>.*$
            ^%(__prefix_line)sAccepted (?:publickey|password) for .* from <HOST>.*$
            ^%(__prefix_line)sDisconnected from (?:invalid|authenticating)? ?user .* <HOST>.*$
            ^%(__prefix_line)sConnection closed by (?:invalid|authenticating)? ?user .* <HOST>.*$
            ^%(__prefix_line)serror: Received disconnect from <HOST>.*$
            ^%(__prefix_line)sNo supported authentication methods available .* from <HOST>.*\[preauth\].*$
            ^%(__prefix_line)skex_exchange_identification: .* <HOST>.*$
ignoreregex =
FILTER_MON
  chmod 0644 /etc/fail2ban/filter.d/sshd-monitor.conf
  ok "Wrote sshd-monitor filter"

  # --- Action: call our Python mailer (detailed) if email configured ---
  if [[ -n "${GMAIL_SENDER:-}" && -n "${GMAIL_DEST:-}" && -n "${APP_PWD:-}" ]]; then
    cat > /etc/fail2ban/action.d/sendmail-gmail.conf <<'ACTIONCONF'
[Definition]
actionstart =
actionstop  =
actioncheck =

# Ban/Unban calls the Python mailer (args: <jail> <ip> <event>)
actionban   = /usr/local/bin/send_email_gmail.py "<name>" "<ip>" "BAN"
actionunban = /usr/local/bin/send_email_gmail.py "<name>" "<ip>" "UNBAN"

[Init]
dest   = root
sender = root@localhost
ACTIONCONF
    chmod 0644 /etc/fail2ban/action.d/sendmail-gmail.conf
    ok "Wrote sendmail-gmail action"
  fi

  # --- Python mailer (detailed HTML + whois) ---
  if [[ -n "${GMAIL_SENDER:-}" && -n "${GMAIL_DEST:-}" && -n "${APP_PWD:-}" ]]; then
    cat > /usr/local/bin/send_email_gmail.py <<'PYMAIL'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Fail2Ban Gmail notifier (HTML report, ASCII-safe)
- Reads Gmail App Password from /root/.gmail_app_password (mode 600)
- Uses env FAIL2BAN_GMAIL_SENDER / FAIL2BAN_GMAIL_DEST for From/To
- Parses syslog to extract attempted username/method/remote-port for the offending IP
Usage: send_email_gmail.py <jail> <ip> <event>
"""
import os, sys, smtplib, ssl, socket, subprocess, re
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path

def read_first_line(path):
    try:
        return Path(path).read_text(encoding="utf-8", errors="ignore").splitlines()[0].strip()
    except Exception:
        return ""

if len(sys.argv) < 3:
    print("Usage: send_email_gmail.py <jail> <ip> <event>")
    sys.exit(1)

jail, ip = sys.argv[1], sys.argv[2]
event = sys.argv[3] if len(sys.argv) > 3 else "EVENT"

sender  = os.environ.get("FAIL2BAN_GMAIL_SENDER", "sender@example.com")
receiver= os.environ.get("FAIL2BAN_GMAIL_DEST", sender)

pwd_file = "/root/.gmail_app_password"
password = read_first_line(pwd_file)
if not password or len(password) != 16 or (" " in password):
    print("ERROR: Gmail App Password missing/invalid in /root/.gmail_app_password")
    sys.exit(2)

# Detect log path
logpath = os.environ.get("FAIL2BAN_SSH_LOGPATH", "/var/log/auth.log")
if not Path(logpath).exists() and Path("/var/log/secure").exists():
    logpath = "/var/log/secure"

# Defaults
username = "Unknown"
auth_method = "Unknown"
remote_port = "Unknown"
result = "Unknown"
log_snippet = "N/A"

# Patterns to extract details from the latest line containing this IP
patterns = [
    (r"Accepted\s+(publickey|password)\s+for\s+(\S+)\s+from\s+" + re.escape(ip) + r"\s+port\s+(\d+)", "SUCCESS"),
    (r"Failed\s+password\s+for\s+invalid\s+user\s+(\S+)\s+from\s+" + re.escape(ip), "FAILURE"),
    (r"Failed\s+password\s+for\s+(\S+)\s+from\s+" + re.escape(ip), "FAILURE"),
    (r"Invalid\s+user\s+(\S+)\s+from\s+" + re.escape(ip), "FAILURE"),
    (r"Disconnected\s+from\s+(?:invalid|authenticating)?\s*user\s+(\S+).*\b" + re.escape(ip) + r"\b", "FAILURE"),
    (r"Connection\s+closed\s+by\s+(?:invalid|authenticating)?\s*user\s+(\S+).*\b" + re.escape(ip) + r"\b", "FAILURE"),
]

# Read last lines from log and parse
try:
    with open(logpath, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()[-1500:]
    for line in reversed(lines):
        if ip not in line:
            continue
        for pat, outcome in patterns:
            m = re.search(pat, line)
            if m:
                if outcome == "SUCCESS":
                    auth_method = m.group(1)
                    username = m.group(2)
                    if len(m.groups()) >= 3:
                        remote_port = m.group(3)
                    result = "SUCCESS"
                else:
                    if "Failed password" in line:
                        auth_method = "password"
                    username = m.group(1)
                    mport = re.search(r"\bport\s+(\d+)", line)
                    if mport:
                        remote_port = mport.group(1)
                    result = "FAILURE"
                log_snippet = line.strip()
                raise StopIteration
except StopIteration:
    pass
except Exception as e:
    log_snippet = "Log parse error: %s" % e

# Reverse DNS (best effort)
try:
    rdns = socket.gethostbyaddr(ip)[0]
except Exception:
    rdns = "Unknown"

# ASN/Country via whois (best effort)
country, asn = "Unknown", "Unknown"
try:
    who = subprocess.check_output(["whois", ip], text=True, timeout=4)
    for ln in who.splitlines():
        ls = ln.strip()
        if country == "Unknown" and re.match(r"(?i)^country\s*:", ls):
            country = ls.split(":",1)[1].strip()
        if asn == "Unknown" and re.search(r"(?i)\b(origin|originas|origin-as|aut-num)\b\s*:", ls):
            asn = ls.split(":",1)[1].strip()
        if country != "Unknown" and asn != "Unknown":
            break
except Exception:
    pass

hostname = socket.gethostname()
timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# Risk simple heuristic
risk = "LOW"
if result == "FAILURE":
    risk = "MEDIUM"
if event.upper() == "BAN":
    risk = "HIGH"

subject = "[Fail2Ban] %s | SSH %s | %s (%s)" % (event, result, ip, country)

def td(k, v):
    return "<tr><th align=\"left\" style=\"border:1px solid #ddd;padding:8px;background:#fafafa;\">%s</th><td style=\"border:1px solid #ddd;padding:8px;\">%s</td></tr>" % (k, v)

html = """<html>
  <body style="font-family: -apple-system, Segoe UI, Arial, sans-serif; margin: 16px; color:#111;">
    <div style="max-width: 760px;">
      <h2 style="margin:0 0 8px 0; color:#8b0000;">Fail2Ban Security Incident Report</h2>
      <div style="font-size:13px; color:#666; margin-bottom:14px;">Automated notification — summary</div>

      <table style="border-collapse:collapse; width:100%; font-size:14px;">
        {event_row}
        {result_row}
        {ts_row}
        {host_row}
      </table>

      <h3 style="margin:18px 0 8px 0;">Connection Details</h3>
      <table style="border-collapse:collapse; width:100%; font-size:14px;">
        {ip_row}
        {rdns_row}
        {country_row}
        {asn_row}
        {user_row}
        {method_row}
        {rport_row}
      </table>

      <h3 style="margin:18px 0 8px 0;">Assessment</h3>
      <div style="border-left:4px solid #8b0000; padding:10px 12px; background:#fff7f7;">
        <p style="margin:0 0 8px 0;">This event was detected by the <b>{jail}</b> jail. If the risk level is <b>HIGH</b>, automated firewall countermeasures have been enforced.</p>
        <p style="margin:0;">Estimated risk level: <b>{risk}</b></p>
      </div>

      <h3 style="margin:18px 0 8px 0;">Correlated Log Snippet</h3>
      <pre style="white-space:pre-wrap; background:#f6f8fa; border:1px solid #eee; padding:10px; font-size:13px; border-radius:6px;">{log_snippet}</pre>

      <h3 style="margin:18px 0 8px 0;">Recommendations</h3>
      <ul style="margin-top:0;">
        <li>Prefer SSH keys; consider disabling password authentication.</li>
        <li>Keep SSH on a nonstandard port and behind a firewall/allowlist where possible.</li>
        <li>Monitor repeated sources; consider permanent blocklists for persistent offenders.</li>
        <li>Rotate credentials and audit authorized_keys regularly.</li>
      </ul>

      <hr style="margin:24px 0 12px 0; border:none; border-top:1px solid #eee;">
      <div style="color:#666; font-size:12px;">
        This automated report was generated by Fail2Ban.
      </div>
    </div>
  </body>
</html>""".format(
    event_row   = td("Event", event),
    result_row  = td("Result", result),
    ts_row      = td("Timestamp", timestamp),
    host_row    = td("Hostname", hostname),
    ip_row      = td("Source IP", ip),
    rdns_row    = td("Reverse DNS", rdns),
    country_row = td("Country", country),
    asn_row     = td("ASN", asn),
    user_row    = td("Attempted Username", username),
    method_row  = td("Auth Method", auth_method),
    rport_row   = td("Remote Port", remote_port),
    jail        = jail,
    risk        = risk,
    log_snippet = (log_snippet or "N/A")
)

msg = MIMEMultipart("alternative")
msg["From"] = sender
msg["To"] = receiver
msg["Subject"] = subject
msg.attach(MIMEText(html, "html"))

try:
    ctx = ssl.create_default_context()
    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.ehlo()
        server.starttls(context=ctx)
        server.ehlo()
        server.login(sender, password)
        server.sendmail(sender, [receiver], msg.as_string())
    print("Mail sent")
except Exception as e:
    print("Mail failed:", e)
    sys.exit(3)
PYMAIL
    chmod 0755 /usr/local/bin/send_email_gmail.py
    sed -i 's/\r$//' /usr/local/bin/send_email_gmail.py || true
    ok "Wrote python mailer"

    # Store App Password securely
    printf '%s\n' "$APP_PWD" > /root/.gmail_app_password
    chmod 600 /root/.gmail_app_password
    ok "Stored App Password in /root/.gmail_app_password (mode 600)"

    # Env file (expose sender/dest/logpath to mailer)
    cat > /etc/fail2ban/fail2ban.local.env <<ENVFILE
FAIL2BAN_GMAIL_SENDER="${GMAIL_SENDER}"
FAIL2BAN_GMAIL_DEST="${GMAIL_DEST}"
FAIL2BAN_SSH_LOGPATH="${SSH_LOGPATH}"
ENVFILE
    chmod 0644 /etc/fail2ban/fail2ban.local.env

    mkdir -p /etc/systemd/system/fail2ban.service.d
    cat > /etc/systemd/system/fail2ban.service.d/10-env.conf <<'DROPINENV'
[Service]
EnvironmentFile=-/etc/fail2ban/fail2ban.local.env
DROPINENV
  fi

  # Clean DB (remove malformed bans) and prep iptables chain if needed
  rm -f /var/lib/fail2ban/fail2ban.sqlite3 || true
  if [[ "${FW_BACKEND}" == "iptables" ]]; then
    flush_chain_iptables "${SSH_PORT}"
  fi

  # Start & ensure iptables jump exists on the chosen SSH port
  service_restart
  if [[ "${FW_BACKEND}" == "iptables" ]]; then
    ensure_jump_iptables "${SSH_PORT}"
  fi

  # Force chain creation via a harmless dummy ban/unban
  fail2ban-client set sshd banip 127.0.0.2 >/dev/null 2>&1 || true
  sleep 0.5
  fail2ban-client set sshd unbanip 127.0.0.2 >/dev/null 2>&1 || true

  echo
  echo "=== INSTALL COMPLETE ==="
  echo "SSH port        : ${SSH_PORT}"
  echo "Firewall backend: ${FW_BACKEND} (banaction=${BANACTION})"
  echo "Email enabled   : $([[ -n "${GMAIL_SENDER:-}" && -n "${GMAIL_DEST:-}" && -n "${APP_PWD:-}" ]] && echo yes || echo no)"
  echo
  echo "Quick checks:"
  echo "  fail2ban-client status sshd"
  if [[ "${FW_BACKEND}" == "iptables" ]]; then
    echo "  iptables -L INPUT -n --line-numbers | grep -i f2b"
    echo "  iptables -L f2b-sshd -n"
  else
    echo "  nft list ruleset | grep -i -A2 -B2 f2b"
  fi
  echo "  # test a ban:"
  echo "  fail2ban-client set sshd banip 203.0.113.10"
  ok "Done."
}

# -------------------------------- Doctor --------------------------------
doctor_firewall() {
  need_root
  detect_firewall_backend
  get_effective_ssh_port
  echo "== Detection =="
  echo "  FW_BACKEND: ${FW_BACKEND}  (BANACTION=${BANACTION})"
  echo "  SSH_PORT  : ${SSH_PORT}"
  echo
  echo "== Jail: sshd =="
  fail2ban-client status sshd || true
  echo
  echo "== Firewall rules =="
  if [[ "${FW_BACKEND}" == "nft" ]]; then
    command -v nft >/dev/null 2>&1 && nft list ruleset | sed -n '1,400p' | grep -i -A2 -B2 f2b || echo "nft not available"
  else
    iptables -L f2b-sshd -n || echo "iptables chain f2b-sshd not present"
  fi
  echo
  echo "== Fail2Ban logs (last 100) =="
  tail -n 100 /var/log/fail2ban.log | egrep -i 'iptables|nft|error|warning' || true
}

# -------------------------------- Menu ----------------------------------
main_menu() {
  echo "===================================================="
  echo " Fail2Ban Manager"
  echo "  1) Unban ONE IP (from ALL jails)"
  echo "  2) Unban ALL IPs (from ALL jails)"
  echo "  3) Install/Configure Fail2Ban (choose SSH port)"
  echo "  4) Doctor (diagnose backend/port/rules)"
  echo "  5) Purge DB (reset bans & rebuild chain)"
  echo "  q) Quit"
  echo "===================================================="
  read -rp "Choose [1/2/3/4/5/q]: " choice
  case "$choice" in
    1) unban_single_ip ;;
    2) unban_all_ips ;;
    3) install_fail2ban_stack ;;
    4) doctor_firewall ;;
    5) purge_db_and_flush ;;
    q|Q) exit 0 ;;
    *) echo "Invalid choice." ; exit 1 ;;
  esac
}

# ------------------------------ Entry point ------------------------------
need_root
main_menu
